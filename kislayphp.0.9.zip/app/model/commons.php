<?php
class commons extends Model{
	function test(){
	return "I am defalt member";
	}
}
?>