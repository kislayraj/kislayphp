<?php
class commonApp extends AppController{
	function index(){
	
	}
	function header(){
	
	}
	function footer(){
	}
	function Home(){
	}
	function cat(){
	
	}
	function getmenuready(){
	
	}
}
?>