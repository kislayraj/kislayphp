<?php include('system\helper\html.php'); 
$result='http://www.google.com';
$html=new html();
$html->start('html');
$html->start('head');
$html->gettag('meta',array('name'=>'keyword','content'=>'lkskl klskl lkfdklds'));
$html->end('head');
$html->start('body');
$html->start('table' ,array('border'=>'1'));
for($i=0; $i<4; $i++){
$html->start('tr');
$html->gettag('td',array('main'=>'rahul'.$i));
$html->end('tr');
}
$html->end('table');
$html->end('body');
$html->end('html');
?>
